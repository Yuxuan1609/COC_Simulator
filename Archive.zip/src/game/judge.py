"""Deterministic gate — requirement check, skill check, @markup resolution."""
from __future__ import annotations
from typing import TYPE_CHECKING
import re as _re

if TYPE_CHECKING:
    from scenario_core import ScenarioWorld, Entity, ActionResult

from scenario_core import parse_markup_all, resolve_graded_result
from .messages import ActionIntent, ActionOutcome
from prompts import log_skill_result, _build_scene_context

_ENTITY_ID_RE = _re.compile(r'^([IEA]+\d+)$')  # e.g. I1, AT2, E3

_DIFFICULTY_ORDER = {"regular": "hard", "hard": "extreme"}


def _escalate_difficulty(difficulty: str) -> str:
    """Escalate difficulty by one level: regular→hard→extreme. Already extreme stays."""
    return _DIFFICULTY_ORDER.get(difficulty, difficulty)


class Judge:
    """Deterministic gate for entity execution.

    No LLM dependencies. Handles:
    - Auto-trigger condition checking
    - Flag-based + entity-ID-based requirement gating
    - Skill check gating + tier determination
    - ##GRADED## result resolution (inline, after skill check)
    - Completion flag setting
    - @markup side effect resolution
    """

    def __init__(self, world: ScenarioWorld):
        self.world = world

    # ── Auto-triggers ──

    def check_auto_triggers(self) -> list[ActionOutcome]:
        """Check all ATs in current scene. Fire those with simple requirements met."""
        results = []
        node = self.world._current_node()
        if not node:
            return results

        for at in node.auto_triggers:
            if not self._check_simple_requirement(at):
                continue
            outcome = self._execute_entity(at)
            results.append(outcome)
        return results

    # ── Interactions ──

    def execute_interaction(self, intent: ActionIntent) -> ActionOutcome:
        """Execute a parsed interaction intent through the gate."""
        node = self.world._current_node()
        if not node:
            return ActionOutcome(intent=intent, success=False,
                                message="当前场景不存在。")

        entity = node.get_interaction(intent.target)
        if not entity:
            available = ', '.join(e.name for e in node.interactions)
            return ActionOutcome(intent=intent, success=False,
                                message=f"没有动作「{intent.target}」。可用：{available or '无'}")

        return self._execute_entity(entity, intent=intent)

    # ── Internal ──

    def _set_completion_flag(self, entity: Entity):
        """Mark entity completed in runtime_state."""
        state = self.world.get_runtime_state(entity.id)
        state.completed = True

    def _find_entity_by_id(self, entity_id: str):
        """Find an entity by ID across graph (scenes + events)."""
        if entity_id in self.world.graph.events:
            return self.world.graph.events[entity_id]
        for node in self.world.graph.nodes.values():
            for e in node.interactions + node.auto_triggers:
                if e.id == entity_id:
                    return e
        return None

    def _is_entity_completed(self, entity) -> bool:
        """Check if an entity has been completed/triggered via runtime_state."""
        if entity.entity_type == "event":
            return self.world.is_event_triggered(entity.id)
        state = self.world.runtime_state.get(entity.id)
        if state:
            return state.completed
        scene = entity.scene or ""
        done = self.world.completed_interactions.get(scene, set())
        return entity.name in done

    def _execute_entity(self, entity: Entity, intent: ActionIntent | None = None) -> ActionOutcome:
        """Run entity through gate and execute."""
        # Check structured requirements (world flags + entity IDs) — hard part only
        if entity.requirement and entity.requirement.strip():
            self._current_entity_id = entity.id
            hard, _ = self._split_requirement(entity.requirement)
            if hard:
                met, msg = self._evaluate_requirement(hard)
                if not met:
                    return ActionOutcome(
                        intent=intent or ActionIntent(action="other"),
                        success=False, message=msg,
                        entity_id=entity.id, entity_type=entity.entity_type
                    )

        # Note: soft requirements (after ||) are evaluated by Parse (LLM) step,
        # not duplicated here. See build_keeper_parse_prompt for soft condition handling.

        # Skill check + ##GRADED## resolution
        skill_tier = ""
        skill_passed = True
        skill_message = ""
        skill_detail = ""

        if self.world.player and entity.type and entity.type not in ("无", "None", ""):
            skill_name = entity.type
            intent_skill = intent.skill_checks[0] if (intent and intent.skill_checks) else skill_name
            difficulty = entity.difficulty if entity.difficulty not in ("None", "", None) else "regular"
            state = self.world.get_runtime_state(entity.id)
            if state.escalated_difficulty:
                difficulty = state.escalated_difficulty
            all_pass, skill_result, skill_tier = self.world.player.check_skill(intent_skill, difficulty)

            skill_passed = all_pass
            skill_message = skill_result
            skill_detail = (
                f"[{entity.id}] {entity.name} | 技能={skill_name} | "
                f"难度={difficulty} | 骰子等级={skill_tier} | {'成功' if all_pass else '失败'}\n"
                f"  {skill_result}"
            )
            log_skill_result(skill_detail)

            # Rule enhancement: trait-based tier correction via LLM sub-agent
            inv_desc = getattr(self.world.player, 'personal_description', '') or \
                       getattr(self.world.player, 'description', '')
            if inv_desc:
                from llm import evaluate_trait_enhancement
                enhancement = evaluate_trait_enhancement(
                    inv_desc=inv_desc,
                    skill_name=skill_name,
                    skill_detail=skill_result,
                    current_tier=skill_tier,
                    entity_name=entity.name,
                    graded_tiers=entity.graded_result,
                )
                new_tier = enhancement.get("tier", skill_tier)
                if new_tier != skill_tier:
                    reason = enhancement.get("reason", "")
                    detail_override = enhancement.get("detail_override")
                    skill_detail += (
                        f"\n  [特质修正] {skill_tier} → {new_tier}：{reason}"
                    )
                    if detail_override:
                        skill_detail += f"\n  修正描述：{detail_override}"
                    log_skill_result(skill_detail)
                    skill_tier = new_tier
                    skill_passed = (skill_tier != "failure")

        # Resolve result text (handle ##GRADED##)
        result_text = entity.result
        has_graded = "##GRADED##" in result_text
        if skill_tier:
            result_text = resolve_graded_result(entity, skill_tier)

        if not skill_passed:
            # Failure penalty: retry tracking + difficulty escalation via runtime_state
            state = self.world.get_runtime_state(entity.id)
            retries = state.retries

            # First failure: escalate difficulty by one level
            if retries == 0:
                new_diff = _escalate_difficulty(difficulty)
                if new_diff != difficulty:
                    state.escalated_difficulty = new_diff
                    skill_detail += f"\n  [难度递增] {difficulty} → {new_diff}"
                    log_skill_result(skill_detail)

            state.retries = retries + 1

            # After difficulty locked (2nd+ failure): LLM creative consequence
            penalty_side_effects = []
            if retries >= 2:
                inv_desc = getattr(self.world.player, 'personal_description', '') or \
                           getattr(self.world.player, 'description', '')
                scene_ctx = _build_scene_context(self.world)
                graded_on_failure = ""
                if entity.graded_result and isinstance(entity.graded_result, dict):
                    graded_on_failure = entity.graded_result.get("on_failure", "")

                if inv_desc:
                    from llm import evaluate_failure_penalty
                    penalty = evaluate_failure_penalty(
                        inv_desc=inv_desc,
                        entity_name=entity.name,
                        skill_name=skill_name,
                        skill_detail=skill_result,
                        failure_tier=skill_tier,
                        scene_context=scene_ctx,
                        graded_on_failure=graded_on_failure,
                        retry_count=retries,
                    )
                    if penalty.get("narrative"):
                        skill_message = penalty["narrative"]
                    for markup in penalty.get("markup_effects", []):
                        parsed = parse_markup_all(markup)
                        penalty_side_effects.extend(parsed)
                    skill_detail += f"\n  [失败惩罚] {skill_message}"
                    log_skill_result(skill_detail)

            return ActionOutcome(
                intent=intent or ActionIntent(action="other"),
                success=False, message=skill_message,
                entity_id=entity.id, entity_type=entity.entity_type,
                skill_tier=skill_tier,
                skill_detail=skill_detail,
                side_effects=penalty_side_effects,
            )

        # Execute — mark completion
        if entity.entity_type == "interaction":
            loc = self.world.current_location
            if loc not in self.world.completed_interactions:
                self.world.completed_interactions[loc] = set()
            self.world.completed_interactions[loc].add(entity.name)
        elif entity.entity_type == "event":
            self.world.triggered_events[entity.id] = True

        # Set completion flag
        self._set_completion_flag(entity)

        # Resolve side effects
        side_effects = []
        for se_text in entity.side_effects:
            parsed = parse_markup_all(se_text)
            side_effects.extend(parsed)

        return ActionOutcome(
            intent=intent or ActionIntent(action="other"),
            success=True,
            message=result_text,
            entity_id=entity.id,
            entity_type=entity.entity_type,
            side_effects=side_effects,
            skill_tier=skill_tier,
            skill_detail=skill_detail,
        )

    @staticmethod
    def _split_requirement(req: str) -> tuple[str, str]:
        """Split requirement by '||': hard (before) | soft (after)."""
        if not req:
            return "", ""
        parts = req.split("||", 1)
        hard = parts[0].strip() if parts[0] else ""
        soft = parts[1].strip() if len(parts) > 1 else ""
        return hard, soft

    # ── Requirement checking ──

    def _is_simple_requirement(self, req: str) -> bool:
        hard, _ = self._split_requirement(req)
        if not hard:
            return True
        # Any hard string with recognizable IDs or logical operators can be parsed
        if "OR" in hard or "AND" in hard:
            return True
        if _ENTITY_ID_RE.match(hard.strip().strip("()（）")):
            return True
        return False

    def _check_simple_requirement(self, entity: Entity) -> bool:
        if not entity.requirement or not entity.requirement.strip():
            return True
        hard, _ = self._split_requirement(entity.requirement)
        if not hard:
            return True
        if self._is_simple_requirement(hard):
            met, _ = self._evaluate_requirement(hard)
            return met
        return False

    def _evaluate_requirement(self, req: str) -> tuple[bool, str]:
        """Evaluate hard requirement string using AND/OR parser + edge graph.

        Order:
        1. String-based AND/OR parsing FIRST (handles OR semantics)
           Must come before edge check because edges are AND-only; requirement strings
           may use OR to relax edge constraints.
        2. Edge-based dependency check SECOND (structural AND, secondary)
        3. No ID found → pass (graceful degradation for LLM-generated text)
        """
        req = req.strip()
        if not req:
            return True, ""

        # Step 1: string-based AND/OR parsing FIRST (handles OR semantics)
        from scenario_core import parse_hard_requirement
        met = parse_hard_requirement(req, self.world.runtime_state)
        if met:
            return True, ""

        # Step 2: edge-based dependency check (structural AND, secondary)
        entity_id = getattr(self, '_current_entity_id', '')
        if entity_id:
            met, msg = self.world.check_edge_requirements(entity_id)
            if not met:
                return False, msg

        return True, ""
